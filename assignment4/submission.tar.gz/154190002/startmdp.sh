#!/bin/sh

cmd="python bairdSolution.py ${@}"
$cmd