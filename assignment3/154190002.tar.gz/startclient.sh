cmd="python3 ./client/client.py ${@}"
$cmd
