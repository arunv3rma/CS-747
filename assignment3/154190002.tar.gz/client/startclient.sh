#!/bin/bash

python3 client.py "$@"